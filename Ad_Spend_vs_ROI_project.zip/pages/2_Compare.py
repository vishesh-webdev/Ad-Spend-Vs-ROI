"""UI-03 Compare (OQ-01, OQ-05, OQ-06, OQ-07, OQ-08)."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
import plotly.express as px  # noqa: E402
import streamlit as st  # noqa: E402

import analysis as an  # noqa: E402
import ui  # noqa: E402

df, _ = ui.page_start("Compare", "Channels, regions, categories and campaign types side by side", "⚖️")
t1, t2, t3, t4 = st.tabs(["Channel metrics", "Region x Category", "Awareness vs Performance", "Loss-making campaigns"])

with t1:
    g = an.by_group(df, "channel_name").rename(columns={"group": "Channel"})
    st.dataframe(g.style.format({"spend": "₹{:,.0f}", "revenue": "₹{:,.0f}", "roi": "{:.0%}", "roas": "{:.2f}",
                                 "ctr": "{:.2%}", "cpc": "₹{:.2f}", "conversion_rate": "{:.2%}", "cpa": "₹{:,.0f}"}),
                 use_container_width=True, hide_index=True)
    m = st.selectbox("Metric", ["ctr", "cpc", "conversion_rate", "cpa"])
    st.plotly_chart(px.bar(g.sort_values(m), x=m, y="Channel", orientation="h", color_discrete_sequence=[ui.RED]),
                    use_container_width=True)
with t2:
    x = an.by_group(df, ["region_name", "category_name"])
    x[["region", "category"]] = x["group"].apply(lambda t: list(t)).tolist()
    piv = x.pivot(index="region", columns="category", values="roi")
    st.plotly_chart(px.imshow(piv, text_auto=".0%", color_continuous_scale=["#F4F1F1", ui.RED], aspect="auto"),
                    use_container_width=True)
with t3:
    g = an.by_group(df, "campaign_type").rename(columns={"group": "Type"})
    st.dataframe(g[["Type", "spend", "revenue", "roi", "roas", "cpa"]], use_container_width=True, hide_index=True)
    w = df.groupby(["campaign_name", "campaign_type"])[["spend_inr", "revenue_inr"]].sum().reset_index()
    w["roi"] = (w.revenue_inr - w.spend_inr) / w.spend_inr
    st.plotly_chart(px.box(w, x="campaign_type", y="roi", color="campaign_type",
                           color_discrete_sequence=[ui.PINK, ui.RED]), use_container_width=True)
with t4:
    n, w = an.negative_campaigns(df), an.wasted_share(df)
    st.metric("Loss-making campaigns", w["campaigns"])
    st.metric("Spend on them", f"₹{w['spend_on_negative'] / 1e5:,.1f} L", f"{w['share_of_spend']:.1%} of total spend", delta_color="off")
    st.dataframe(n, use_container_width=True, hide_index=True)

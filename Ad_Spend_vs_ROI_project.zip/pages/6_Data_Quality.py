"""UI-07 Data quality (BR-12, RULE-10)."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
import streamlit as st  # noqa: E402

import ui  # noqa: E402
from data_loader import missing_summary  # noqa: E402

ui.setup("Data quality", "🧹")
ui.header("Data quality", "What was checked, what was rejected and why")
raw, good, rejects = ui.get_data()
a, b, c = st.columns(3)
a.metric("Raw rows", f"{len(raw):,}")
b.metric("Clean rows used", f"{len(good):,}")
c.metric("Rows rejected", len(rejects))
st.subheader("Rejected rows (never silently fixed)")
st.dataframe(rejects[["perf_id", "campaign_id", "perf_date", "spend_inr", "revenue_inr", "reject_reason"]],
             use_container_width=True, hide_index=True)
st.subheader("Missing values kept as 'not available'")
st.dataframe(missing_summary(raw), use_container_width=True, hide_index=True)
st.caption("Rates such as CTR and CPA skip rows where a needed value is missing; they are never treated as zero.")

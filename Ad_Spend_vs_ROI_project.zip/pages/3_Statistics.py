"""UI-04 EDA and Statistics (OQ-03, OQ-04, OQ-09, OQ-10)."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
import numpy as np  # noqa: E402
import plotly.express as px  # noqa: E402
import streamlit as st  # noqa: E402

import analysis as an  # noqa: E402
import ui  # noqa: E402

df, _ = ui.page_start("Statistics", "Is spend really linked to revenue, and does extra spend keep paying back?", "📊")
t1, t2, t3, t4 = st.tabs(["Spend vs revenue", "Diminishing returns", "Channel ROI test", "Budget what-if"])

with t1:
    c = an.correlation(df, "channel_name")
    st.dataframe(c, use_container_width=True, hide_index=True)
    s = df.sample(min(4000, len(df)), random_state=42)
    st.plotly_chart(px.scatter(s, x="spend_inr", y="revenue_inr", color="channel_name", opacity=0.5,
                               color_discrete_sequence=ui.PALETTE, log_x=True, log_y=True), use_container_width=True)
    st.caption("Correlation shows that two values move together; it does not prove that spend causes revenue.")
with t2:
    d = an.diminishing_returns(df)
    st.dataframe(d, use_container_width=True, hide_index=True)
    ui.insight("A slope below 1.0 means that doubling spend gives less than double revenue.")
with t3:
    r = an.channel_roi_test(df)
    if not r["ok"]:
        st.warning(r["message"])
    else:
        a, b = st.columns(2)
        a.metric("ANOVA p-value", f"{r['anova_p']:.3g}")
        b.metric("Kruskal-Wallis p-value", f"{r['kruskal_p']:.3g}")
        (st.success if r["significant"] else st.info)(r["verdict"])
with t4:
    chans = sorted(df.channel_name.unique())
    if len(chans) < 2:
        st.info("Select at least two channels in the sidebar to use the what-if.")
    else:
        a, b, c3 = st.columns(3)
        src = a.selectbox("Move budget FROM", chans, index=0)
        dst = b.selectbox("Move budget TO", chans, index=min(1, len(chans) - 1))
        pct = c3.slider("Share of source spend moved (%)", 5, 50, 20, step=5)
        res = an.what_if(df, src, dst, pct)
        if not res["ok"]:
            st.warning(res["message"])
        else:
            st.metric("Estimated weekly revenue change", f"₹{res['net_weekly_change']:,.0f}",
                      f"moves ₹{res['moved_weekly_inr']:,.0f} per week", delta_color="off")
            st.caption(res["note"])

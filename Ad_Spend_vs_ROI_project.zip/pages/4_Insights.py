"""UI-05 Insights."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
import streamlit as st  # noqa: E402

import analysis as an  # noqa: E402
import ui  # noqa: E402

df, _ = ui.page_start("Insights", "Plain-language findings for the current filters", "💡")
g = an.by_group(df, "channel_name")
m = an.monthly(df)
w = an.wasted_share(df)
t = an.channel_roi_test(df)
d = an.diminishing_returns(df)
k = an.kpis(df)
ui.insight(f"Overall ROAS is <b>{k['roas']:.2f}x</b> (ROI {k['roi']:.0%}) on ₹{k['spend'] / 1e7:.2f} Cr spend.")
ui.insight(f"Best channel: <b>{g.iloc[0].group}</b> ({g.iloc[0].roas:.2f}x). Weakest: <b>{g.iloc[-1].group}</b> ({g.iloc[-1].roas:.2f}x).")
ui.insight(f"Best month: <b>{m.loc[m.roi.idxmax()].year_month}</b>; weakest month: <b>{m.loc[m.roi.idxmin()].year_month}</b>.")
ui.insight(f"<b>{w['campaigns']}</b> loss-making campaigns used <b>{w['share_of_spend']:.1%}</b> of spend (₹{w['spend_on_negative'] / 1e5:,.1f} L).")
if t["ok"]:
    ui.insight(t["verdict"] + f" (ANOVA p = {t['anova_p']:.3g}).")
if not d.empty:
    n = int((d.verdict == "Diminishing returns").sum())
    ui.insight(f"{n} of {len(d)} channels show diminishing returns: extra spend earns progressively less.")
st.caption("Synthetic data: these insights show how the method works, not real market results.")

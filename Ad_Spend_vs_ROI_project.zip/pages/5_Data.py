"""UI-06 Data and download (BR-14)."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
import streamlit as st  # noqa: E402

import ui  # noqa: E402

df, _ = ui.page_start("Data", "Browse the filtered rows and download them", "🗂️")
st.write(f"**{len(df):,} rows**, {df.shape[1]} columns")
st.dataframe(df.head(1000), use_container_width=True, hide_index=True)
st.caption("Showing the first 1,000 rows. The download contains all filtered rows.")
st.download_button("Download filtered data (CSV)", df.to_csv(index=False).encode("utf-8"),
                   file_name="ad_spend_roi_filtered.csv", mime="text/csv")

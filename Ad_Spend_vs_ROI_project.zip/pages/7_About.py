"""UI-08 About."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
import streamlit as st  # noqa: E402

import ui  # noqa: E402

ui.setup("About", "ℹ️")
ui.header("About", "Ad Spend vs ROI Analysis")
st.markdown("""
**Student:** Vishesh Yadav  |  **Roll No:** 2500320140165  |  **MCA 2nd Year (Data Analytics), ABES**  
**Mentor:** Anjali Pandey Ma'am  |  **GitHub:** vishesh-webdev

**Data:** fully synthetic (fictional organisation, names and places). Findings show how the method works; they are not real market results.

**Definitions:** ROI = (Revenue - Spend) / Spend. ROAS = Revenue / Spend. CTR = Clicks / Impressions.
CPC = Spend / Clicks. Conversion rate = Conversions / Clicks. CPA = Spend / Conversions.
A ratio with a zero or missing divisor is shown as not available, never as 0.
""")

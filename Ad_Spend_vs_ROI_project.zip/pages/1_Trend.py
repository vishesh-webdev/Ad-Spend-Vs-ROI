"""UI-02 Trend (OQ-02)."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
import plotly.graph_objects as go  # noqa: E402
import plotly.express as px  # noqa: E402
import streamlit as st  # noqa: E402

import analysis as an  # noqa: E402
import ui  # noqa: E402

df, _ = ui.page_start("Trend", "How do spend, revenue and ROI change month by month?", "📅")
m = an.monthly(df)
fig = go.Figure()
fig.add_bar(x=m.year_month, y=m.spend_inr, name="Spend", marker_color=ui.PINK)
fig.add_scatter(x=m.year_month, y=m.revenue_inr, name="Revenue", line=dict(color=ui.RED, width=3))
fig.update_layout(height=380, margin=dict(l=0, r=0, t=10, b=0), yaxis_title="INR", legend=dict(orientation="h"))
st.plotly_chart(fig, use_container_width=True)

c1, c2 = st.columns(2)
with c1:
    st.subheader("ROI by month")
    f2 = px.line(m, x="year_month", y="roi", markers=True, color_discrete_sequence=[ui.RED])
    f2.update_layout(height=300, margin=dict(l=0, r=0, t=10, b=0), yaxis_tickformat=".0%")
    st.plotly_chart(f2, use_container_width=True)
with c2:
    st.subheader("Seasonality index (1.00 = average)")
    s = an.seasonality_index(df)
    f3 = px.bar(s, x="month", y="index", color_discrete_sequence=[ui.RED])
    f3.add_hline(y=1, line_dash="dash")
    f3.update_layout(height=300, margin=dict(l=0, r=0, t=10, b=0))
    st.plotly_chart(f3, use_container_width=True)
hi, lo = m.loc[m.roi.idxmax()], m.loc[m.roi.idxmin()]
ui.insight(f"Best month: <b>{hi.year_month}</b> (ROI {hi.roi:.0%}). Weakest: <b>{lo.year_month}</b> (ROI {lo.roi:.0%}). "
           "Months above 1.00 on the index beat the average return.")

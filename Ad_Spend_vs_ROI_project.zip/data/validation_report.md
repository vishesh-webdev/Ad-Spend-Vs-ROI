# Validation report - Ad Spend vs ROI Analysis (synthetic data, seed 42)

## 1. Row counts

| table | rows | plan |
|---|---|---|
| dim_channel | 7 | 7 |
| dim_region | 5 | 5 |
| dim_product_category | 4 | 4 |
| dim_campaign | 60 | 60 |
| fact_ad_performance | 13633 | 10,000+ (Step 1 objective O-01) |

Joined view `vw_ad_analysis`: 13633 rows x 37 columns.

## 2. Foreign-key check

`PRAGMA foreign_key_check` violations: **0**

## 3. Range / rule check (on the raw, unclean data)

| check | violations | expected |
|---|---|---|
| spend_inr < 0 | 0 | 0 |
| revenue_inr < 0 | 0 | 0 |
| clicks > impressions | 0 | 0 |
| conversions > clicks | 0 | 0 |
| perf_date outside 2024-11-01..2026-10-31 | 0 | 0 |
| perf_date outside campaign start/end | 0 | 0 |
| campaign without a manager (missing) | 2 | 2 planted |

## 4. Planted data-quality issues (answer key: data/injected_issues.csv)

| issue | found | share | planted |
|---|---|---|---|
| missing impressions | 272 | 2.00% | 2-3% |
| missing clicks | 340 | 2.49% | 2-3% |
| missing conversions | 272 | 2.00% | 2-3% |
| duplicate (campaign, date) pairs | 3 |  | 3 |
| spend outliers (> 6x daily budget) | 5 |  | 5 |
| revenue outliers (ROAS > 30) | 3 |  | 3 |

## 5. Patterns built into the data (measured on rows without planted issues)

**P1 - Channel ROI ranking** (E-mail and Google Search best, Display and Instagram weakest)

| channel_name | spend_inr | revenue_inr | ROAS | ROI |
|---|---|---|---|---|
| Google Search | 29610498 | 142225675 | 4.8 | 3.8 |
| E-mail | 5289636 | 25311482 | 4.79 | 3.79 |
| LinkedIn | 14189092 | 32584669 | 2.3 | 1.3 |
| Meta (Facebook) | 21853217 | 48505326 | 2.22 | 1.22 |
| Instagram | 18836014 | 35639242 | 1.89 | 0.89 |
| YouTube | 24651389 | 33522403 | 1.36 | 0.36 |
| Display Network | 12582756 | 13876870 | 1.1 | 0.1 |

**P2 - Seasonality** (ROAS index by calendar month; 1.00 = average; Oct-Dec above, Jun-Jul below)

| month | index_vs_avg |
|---|---|
| 1 | 1.04 |
| 2 | 0.9 |
| 3 | 0.91 |
| 4 | 0.95 |
| 5 | 0.96 |
| 6 | 0.87 |
| 7 | 0.89 |
| 8 | 1.06 |
| 9 | 1.17 |
| 10 | 1.25 |
| 11 | 1.17 |
| 12 | 1.05 |

**P3 - Diminishing returns** (log-log slope of revenue on spend; below 1.0 means each extra rupee earns less)

| channel | slope |
|---|---|
| Display Network | 0.34 |
| E-mail | 0.66 |
| Google Search | 0.89 |
| Instagram | 0.42 |
| LinkedIn | 0.76 |
| Meta (Facebook) | 0.93 |
| YouTube | 0.81 |

**P4 - Loss-making campaigns:** 7 of 60 campaigns (12%) have ROI < 0; they absorbed 10.2% of total spend.

**P5 - Awareness vs Performance** (performance campaigns return more)

| campaign_type | ROAS |
|---|---|
| Awareness | 1.58 |
| Performance | 3.47 |

**P6 - Regions** (West and South best, Central and East weakest)

| region_name | ROAS |
|---|---|
| West | 3.4 |
| Central | 3.08 |
| South | 2.74 |
| North | 1.94 |
| East | 1.7 |

Total spend in dataset: INR 13.61 crore over 24 months; total revenue INR 35.80 crore.

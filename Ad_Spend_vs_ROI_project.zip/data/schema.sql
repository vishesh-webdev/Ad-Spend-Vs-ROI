
PRAGMA foreign_keys = ON;

CREATE TABLE dim_channel (
    channel_id     INTEGER PRIMARY KEY,
    channel_name   TEXT    NOT NULL UNIQUE,
    channel_group  TEXT    NOT NULL CHECK (channel_group IN ('Search','Social','Video','Direct','Display')),
    billing_model  TEXT    NOT NULL CHECK (billing_model IN ('CPC','CPM','Flat')),
    funnel_stage   TEXT    NOT NULL CHECK (funnel_stage IN ('Upper','Mid','Lower'))
);

CREATE TABLE dim_region (
    region_id    INTEGER PRIMARY KEY,
    region_name  TEXT NOT NULL UNIQUE,
    hub_city     TEXT NOT NULL,
    market_tier  TEXT NOT NULL CHECK (market_tier IN ('Metro','Tier-1','Tier-2'))
);

CREATE TABLE dim_product_category (
    category_id          INTEGER PRIMARY KEY,
    category_name        TEXT NOT NULL UNIQUE,
    avg_order_value_inr  REAL NOT NULL CHECK (avg_order_value_inr > 0),
    gross_margin_pct     REAL NOT NULL CHECK (gross_margin_pct BETWEEN 0 AND 100)
);

CREATE TABLE dim_campaign (
    campaign_id       INTEGER PRIMARY KEY,
    campaign_name     TEXT    NOT NULL UNIQUE,
    channel_id        INTEGER NOT NULL REFERENCES dim_channel(channel_id),
    region_id         INTEGER NOT NULL REFERENCES dim_region(region_id),
    category_id       INTEGER NOT NULL REFERENCES dim_product_category(category_id),
    campaign_type     TEXT    NOT NULL CHECK (campaign_type IN ('Awareness','Performance')),
    objective         TEXT    NOT NULL,
    campaign_manager  TEXT,
    start_date        TEXT    NOT NULL,
    end_date          TEXT    NOT NULL,
    daily_budget_inr  REAL    NOT NULL CHECK (daily_budget_inr > 0),
    CHECK (end_date >= start_date)
);

-- No UNIQUE(campaign_id, perf_date) on purpose: duplicate days are a planted
-- data-quality issue that the cleaning step (RULE-10) must find and report.
CREATE TABLE fact_ad_performance (
    perf_id      INTEGER PRIMARY KEY,
    campaign_id  INTEGER NOT NULL REFERENCES dim_campaign(campaign_id),
    perf_date    TEXT    NOT NULL,
    spend_inr    REAL    NOT NULL CHECK (spend_inr >= 0),
    impressions  INTEGER CHECK (impressions >= 0),
    clicks       INTEGER CHECK (clicks >= 0),
    conversions  INTEGER CHECK (conversions >= 0),
    revenue_inr  REAL    NOT NULL CHECK (revenue_inr >= 0),
    CHECK (clicks <= impressions),
    CHECK (conversions <= clicks)
);
CREATE INDEX ix_fact_campaign ON fact_ad_performance(campaign_id);
CREATE INDEX ix_fact_date     ON fact_ad_performance(perf_date);

CREATE VIEW vw_ad_analysis AS
SELECT
    f.perf_id, f.campaign_id, c.campaign_name, c.campaign_type, c.objective, c.campaign_manager,
    c.daily_budget_inr,
    ch.channel_id, ch.channel_name, ch.channel_group, ch.funnel_stage,
    r.region_id, r.region_name,
    p.category_id, p.category_name, p.avg_order_value_inr, p.gross_margin_pct,
    f.perf_date,
    CAST(strftime('%Y', f.perf_date) AS INTEGER)                      AS year,
    CAST(strftime('%m', f.perf_date) AS INTEGER)                      AS month,
    strftime('%Y-%m', f.perf_date)                                    AS year_month,
    'Q' || ((CAST(strftime('%m', f.perf_date) AS INTEGER) + 2) / 3)   AS quarter,
    CASE strftime('%w', f.perf_date) WHEN '0' THEN 'Sunday' WHEN '1' THEN 'Monday'
         WHEN '2' THEN 'Tuesday' WHEN '3' THEN 'Wednesday' WHEN '4' THEN 'Thursday'
         WHEN '5' THEN 'Friday' ELSE 'Saturday' END                   AS day_name,
    CASE WHEN strftime('%w', f.perf_date) IN ('0','6') THEN 1 ELSE 0 END AS is_weekend,
    CASE WHEN strftime('%m-%d', f.perf_date) BETWEEN '10-15' AND '11-15' THEN 1 ELSE 0 END AS is_festival_season,
    f.spend_inr, f.impressions, f.clicks, f.conversions, f.revenue_inr,
    CASE WHEN f.spend_inr > 0 THEN ROUND((f.revenue_inr - f.spend_inr) * 1.0 / f.spend_inr, 4) END AS roi,
    CASE WHEN f.spend_inr > 0 THEN ROUND(f.revenue_inr * 1.0 / f.spend_inr, 4) END                 AS roas,
    CASE WHEN f.impressions > 0 THEN ROUND(f.clicks * 1.0 / f.impressions, 6) END                  AS ctr,
    CASE WHEN f.clicks > 0 THEN ROUND(f.spend_inr * 1.0 / f.clicks, 2) END                         AS cpc_inr,
    CASE WHEN f.clicks > 0 THEN ROUND(f.conversions * 1.0 / f.clicks, 6) END                       AS conversion_rate,
    CASE WHEN f.conversions > 0 THEN ROUND(f.spend_inr * 1.0 / f.conversions, 2) END               AS cpa_inr,
    ROUND(f.revenue_inr - f.spend_inr, 2)                                                          AS profit_inr
FROM fact_ad_performance f
JOIN dim_campaign         c  ON c.campaign_id = f.campaign_id
JOIN dim_channel          ch ON ch.channel_id = c.channel_id
JOIN dim_region           r  ON r.region_id   = c.region_id
JOIN dim_product_category p  ON p.category_id = c.category_id;

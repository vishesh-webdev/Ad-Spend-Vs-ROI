"""UI-01 Overview. Run: streamlit run app.py"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent / "src"))
import plotly.express as px  # noqa: E402
import streamlit as st  # noqa: E402

import analysis as an  # noqa: E402
import ui  # noqa: E402

df, _ = ui.page_start("Overview", "Which channels earn the most for every rupee spent?")
ui.kpi_cards(an.kpis(df))

g = an.by_group(df, "channel_name")
st.subheader("ROI by channel (OQ-01)")
fig = px.bar(g.sort_values("roas"), x="roas", y="group", orientation="h", color="roas",
             color_continuous_scale=["#D9B5BC", ui.RED], labels={"roas": "ROAS (revenue per ₹1 spend)", "group": ""})
fig.update_layout(coloraxis_showscale=False, height=380, margin=dict(l=0, r=0, t=10, b=0))
st.plotly_chart(fig, use_container_width=True)

best, worst = g.iloc[0], g.iloc[-1]
ui.insight(f"<b>{best.group}</b> earns ₹{best.roas:.2f} for every ₹1 spent; <b>{worst.group}</b> earns only "
           f"₹{worst.roas:.2f}. Wasted spend: {an.wasted_share(df)['share_of_spend']:.1%} of the budget sits in "
           f"{an.wasted_share(df)['campaigns']} loss-making campaigns.")
st.caption("All data is synthetic. Use the pages in the sidebar for trends, comparisons, statistics and data quality.")

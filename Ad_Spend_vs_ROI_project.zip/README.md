# Ad Spend vs ROI Analysis

Data Analytics project by **Vishesh Yadav** (Roll No. 2500320140165), MCA 2nd Year, ABES Engineering College.
Mentor: Anjali Pandey Ma'am. GitHub: vishesh-webdev.

A Python + Streamlit app that answers ten operational questions (OQ-01 to OQ-10) about advertising spend and
return on investment: channel ROI, monthly trends and seasonality, loss-making campaigns, diminishing returns,
statistical tests and a budget what-if. **All data is synthetic** (fictional company, names and places).

## Folder structure
```
app.py                  Overview page (UI-01)
pages/                  Trend, Compare, Statistics, Insights, Data, Data quality, About
src/generate_data.py    Creates the synthetic data (seed 42) and data/app.db
src/data_loader.py      Loads the SQLite view and cleans it (RULE-05, RULE-06, RULE-10)
src/analysis.py         KPIs and statistics (RULE-01 .. RULE-08)
src/ui.py               Tailwind header and KPI cards, shared sidebar filters
data/                   app.db, CSV per table, Excel workbook, validation_report.md
tests/                  pytest: data, analysis, app (Streamlit AppTest)
live_dashboard/         Self-contained HTML version of the dashboard
docs/                   Project documents (Steps 1 to 5)
```

## Run
```bash
python -m venv .venv
.venv\Scripts\activate            # Windows   (macOS/Linux: source .venv/bin/activate)
pip install -r requirements.txt
python src/generate_data.py       # only if you want to regenerate data/app.db
streamlit run app.py
pytest -q
```

## Deploy (Streamlit Community Cloud)
1. Push this folder to GitHub (`data/app.db` must be committed; `.venv/` is ignored).
2. Open https://share.streamlit.io, sign in with GitHub, choose **Create app**.
3. Repository: your repo, branch `main`, main file `app.py`. Click **Deploy**.

## Definitions
ROI = (Revenue - Spend) / Spend | ROAS = Revenue / Spend | CTR = Clicks / Impressions |
CPC = Spend / Clicks | Conversion rate = Conversions / Clicks | CPA = Spend / Conversions.
A ratio with a zero or missing divisor is "not available", never 0.

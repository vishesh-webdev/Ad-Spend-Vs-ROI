"""TC-T app tests with Streamlit AppTest (skipped automatically if Streamlit is not installed)."""
from pathlib import Path

import pytest

pytest.importorskip("streamlit")
from streamlit.testing.v1 import AppTest  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
PAGES = ["app.py"] + [f"pages/{p.name}" for p in sorted((ROOT / "pages").glob("*.py"))]


@pytest.mark.parametrize("page", PAGES)
def test_tct40_every_page_renders_without_error(page):
    at = AppTest.from_file(str(ROOT / page), default_timeout=60).run()
    assert not at.exception, [e.value for e in at.exception]


def test_tct41_overview_has_filters_and_charts():
    at = AppTest.from_file(str(ROOT / "app.py"), default_timeout=60).run()
    assert len(at.sidebar.multiselect) == 3


def test_tct42_empty_filter_shows_warning_not_crash():
    at = AppTest.from_file(str(ROOT / "app.py"), default_timeout=60).run()
    at.sidebar.multiselect[0].set_value([]).run()
    assert not at.exception
    assert any("No data" in w.value for w in at.warning)

"""TC-T data tests: database, keys, cleaning."""
import sqlite3
import time

import numpy as np
import pandas as pd
import pytest

from data_loader import DB_PATH, clean, load_raw, load_clean, missing_summary


@pytest.fixture(scope="module")
def con():
    c = sqlite3.connect(DB_PATH)
    c.execute("PRAGMA foreign_keys = ON")
    yield c
    c.close()


def test_tct01_database_file_exists():
    assert DB_PATH.exists()


def test_tct02_table_row_counts(con):
    q = lambda t: con.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0]
    assert q("dim_channel") == 7 and q("dim_region") == 5
    assert q("dim_product_category") == 4 and q("dim_campaign") == 60
    assert q("fact_ad_performance") >= 10000


def test_tct03_view_has_30_to_40_columns(con):
    assert 30 <= len(pd.read_sql("SELECT * FROM vw_ad_analysis LIMIT 1", con).columns) <= 40


def test_tct04_primary_keys_unique(con):
    for t, pk in [("dim_channel", "channel_id"), ("dim_region", "region_id"),
                  ("dim_product_category", "category_id"), ("dim_campaign", "campaign_id"),
                  ("fact_ad_performance", "perf_id")]:
        total, distinct = con.execute(f"SELECT COUNT({pk}), COUNT(DISTINCT {pk}) FROM {t}").fetchone()
        assert total == distinct, t


def test_tct05_foreign_keys_valid(con):
    assert con.execute("PRAGMA foreign_key_check").fetchall() == []


def test_tct06_foreign_keys_are_enforced(con):
    with pytest.raises(sqlite3.IntegrityError):
        con.execute("INSERT INTO fact_ad_performance(perf_id,campaign_id,perf_date,spend_inr,revenue_inr) "
                    "VALUES (999999, 99999, '2025-01-01', 1, 1)")
    con.rollback()


def test_tct07_raw_data_loads_with_expected_columns():
    df = load_raw()
    for c in ["perf_id", "channel_name", "region_name", "category_name", "spend_inr", "revenue_inr", "roi"]:
        assert c in df.columns
    assert len(df) >= 10000


def test_tct08_load_is_fast():
    t = time.perf_counter()
    load_clean()
    assert time.perf_counter() - t < 3.0


def test_tct09_missing_database_gives_clear_error(tmp_path):
    with pytest.raises(FileNotFoundError):
        load_raw(tmp_path / "nope.db")


def _tiny():
    return pd.DataFrame({
        "perf_id": [1, 2, 3, 4, 5], "campaign_id": [1, 1, 1, 2, 2],
        "perf_date": ["2025-01-01", "2025-01-02", "2025-01-02", "2025-01-01", "2025-01-02"],
        "spend_inr": [100.0, 100.0, 100.0, 5000.0, 100.0],
        "revenue_inr": [300.0, 300.0, 300.0, 100.0, 90000.0],
        "daily_budget_inr": [100.0, 100.0, 100.0, 100.0, 100.0],
        "impressions": [1000, 1000, 1000, 1000, 1000], "clicks": [10, 10, 10, 10, 10],
        "conversions": [1, 1, 1, 1, 1]})


def test_tct10_cleaning_rejects_duplicate_and_outliers():
    good, rej = clean(_tiny())
    assert set(rej.reject_reason) == {"duplicate campaign-day", "spend outlier (> 6x daily budget)",
                                      "revenue outlier (ROAS > 30)"}
    assert len(good) == 2 and len(rej) == 3


def test_tct11_cleaning_rejects_negative_and_missing_keys():
    d = _tiny().iloc[:2].copy()
    d.loc[0, "spend_inr"] = -5
    d.loc[1, "revenue_inr"] = np.nan
    good, rej = clean(d)
    assert len(good) == 0
    assert set(rej.reject_reason) == {"negative amount", "missing key field"}


def test_tct12_cleaning_keeps_planted_count_on_real_data():
    raw, good, rej = load_clean()
    assert len(rej) == 11                      # 5 spend + 3 revenue outliers + 3 duplicates
    assert len(good) + len(rej) == len(raw)
    assert good.duplicated(subset=["campaign_id", "perf_date"]).sum() == 0


def test_tct13_missing_summary_reports_shares():
    raw, good, rej = load_clean()
    m = missing_summary(raw).set_index("column")
    assert 1.5 <= m.loc["clicks", "share_%"] <= 3.5

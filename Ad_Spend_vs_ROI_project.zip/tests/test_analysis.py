"""TC-T analysis tests: every KPI formula on a tiny dataset with hand-calculated answers."""
import numpy as np
import pandas as pd
import pytest

import analysis as an
from data_loader import load_clean


@pytest.fixture
def tiny():
    return pd.DataFrame({
        "campaign_id": [1, 1, 2, 2], "campaign_name": ["A", "A", "B", "B"],
        "channel_name": ["X", "X", "Y", "Y"], "campaign_type": ["Performance"] * 2 + ["Awareness"] * 2,
        "year_month": ["2025-01", "2025-02", "2025-01", "2025-02"], "month": [1, 2, 1, 2],
        "week_start": pd.to_datetime(["2024-12-30", "2025-01-27", "2024-12-30", "2025-01-27"]),
        "spend_inr": [100.0, 200.0, 100.0, 100.0], "revenue_inr": [300.0, 500.0, 50.0, 60.0],
        "impressions": [1000, 2000, 1000, 1000], "clicks": [50, 100, 20, 20],
        "conversions": [5, 10, 1, 1]})


@pytest.fixture(scope="module")
def real():
    return load_clean()[1]


def test_tct20_roi_roas(tiny):
    k = an.kpis(tiny)
    assert k["spend"] == 500 and k["revenue"] == 910
    assert k["roas"] == pytest.approx(1.82)
    assert k["roi"] == pytest.approx(0.82)


def test_tct21_ctr_cpc_cvr_cpa(tiny):
    k = an.kpis(tiny)
    assert k["ctr"] == pytest.approx(0.038)          # 190 clicks / 5000 impressions
    assert k["cpc"] == pytest.approx(500 / 190)
    assert k["conversion_rate"] == pytest.approx(17 / 190)
    assert k["cpa"] == pytest.approx(500 / 17)


def test_tct22_zero_divisor_is_not_available_not_zero():
    d = pd.DataFrame({"spend_inr": [0.0], "revenue_inr": [0.0], "impressions": [0], "clicks": [0], "conversions": [0]})
    k = an.kpis(d)
    assert np.isnan(k["roi"]) and np.isnan(k["roas"]) and np.isnan(k["ctr"]) and np.isnan(k["cpa"])


def test_tct23_missing_values_are_skipped_in_rates(tiny):
    t = tiny.copy()
    t.loc[0, "clicks"] = np.nan
    k = an.kpis(t)
    assert k["ctr"] == pytest.approx(140 / 4000)     # row 0 left out of numerator AND divisor


def test_tct24_group_table(tiny):
    g = an.by_group(tiny, "channel_name").set_index("group")
    assert g.loc["X", "roas"] == pytest.approx(800 / 300)
    assert g.loc["Y", "roi"] == pytest.approx(-0.45)
    assert list(g.index) == ["X", "Y"]                # sorted by ROAS, best first


def test_tct25_monthly_and_seasonality(tiny):
    m = an.monthly(tiny).set_index("year_month")
    assert m.loc["2025-01", "roas"] == pytest.approx(350 / 200)
    s = an.seasonality_index(tiny).set_index("month")
    assert s["index"].mean() == pytest.approx(1.0, abs=0.2)


def test_tct26_negative_campaigns_ranked(tiny):
    n = an.negative_campaigns(tiny)
    assert list(n.campaign_name) == ["B"] and n.loss_inr.iloc[0] == pytest.approx(90)
    w = an.wasted_share(tiny)
    assert w["spend_on_negative"] == 200 and w["share_of_spend"] == pytest.approx(0.4)


def test_tct27_correlation_perfect_line():
    d = pd.DataFrame({"spend_inr": np.arange(1.0, 21), "revenue_inr": np.arange(1.0, 21) * 3,
                      "channel_name": "X"})
    c = an.correlation(d, "channel_name")
    assert c.pearson_r.iloc[0] == pytest.approx(1.0) and c.spearman_rho.iloc[1] == pytest.approx(1.0)


def test_tct28_diminishing_returns_recovers_known_exponent():
    s = np.linspace(100, 5000, 200)
    d = pd.DataFrame({"spend_inr": s, "revenue_inr": 5 * s ** 0.7, "channel_name": "X"})
    r = an.diminishing_returns(d).iloc[0]
    assert r.slope == pytest.approx(0.7, abs=1e-6)
    assert r.verdict == "Diminishing returns"


def test_tct29_linear_data_is_not_flagged():
    s = np.linspace(100, 5000, 200)
    rng = np.random.default_rng(1)
    d = pd.DataFrame({"spend_inr": s, "revenue_inr": 3 * s * rng.lognormal(0, 0.05, 200), "channel_name": "X"})
    assert an.diminishing_returns(d).iloc[0].verdict == "No clear diminishing returns"


def test_tct30_anova_detects_and_rejects(tiny):
    rng = np.random.default_rng(0)
    rows = []
    for ch, mult in (("A", 4.0), ("B", 1.0)):
        for w in range(30):
            sp = 1000.0
            rows.append(dict(campaign_id=1 if ch == "A" else 2, channel_name=ch,
                             week_start=pd.Timestamp("2025-01-06") + pd.Timedelta(weeks=w),
                             spend_inr=sp, revenue_inr=sp * mult * rng.lognormal(0, 0.1)))
    diff = an.channel_roi_test(pd.DataFrame(rows))
    assert diff["ok"] and diff["significant"]
    same = pd.DataFrame(rows)
    same.loc[same.channel_name == "A", "revenue_inr"] = same.loc[same.channel_name == "B", "revenue_inr"].to_numpy()
    assert an.channel_roi_test(same)["significant"] is False


def test_tct31_what_if_rules(real):
    assert an.what_if(real, "Google Search", "Google Search", 10)["ok"] is False
    assert an.what_if(real, "Google Search", "Display Network", 0)["ok"] is False
    r = an.what_if(real, "Display Network", "Google Search", 20)
    assert r["ok"] and r["net_weekly_change"] > 0 and "Estimate" in r["note"]


def test_tct32_real_data_patterns(real):
    g = an.by_group(real, "channel_name")
    assert set(g.group.head(2)) == {"Google Search", "E-mail"}
    assert g.group.iloc[-1] == "Display Network"
    pt = an.by_group(real, "campaign_type").set_index("group")
    assert pt.loc["Performance", "roas"] > pt.loc["Awareness", "roas"]
    assert 4 <= an.wasted_share(real)["campaigns"] <= 9


def test_tct33_empty_filter_does_not_crash(real):
    e = real.iloc[0:0]
    k = an.kpis(e)
    assert k["rows"] == 0 and np.isnan(k["roas"])
    assert an.by_group(e, "channel_name").empty
    assert an.negative_campaigns(e).empty
    assert an.channel_roi_test(e)["ok"] is False

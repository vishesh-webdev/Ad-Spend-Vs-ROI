"""Analysis functions: KPIs and statistics for OQ-01 .. OQ-10 (RULE-01 .. RULE-09)."""
import numpy as np
import pandas as pd
from scipy import stats

ALPHA = 0.05   # RULE-07


def safe_div(a, b):
    """RULE-06: division by zero / missing gives NaN ("not available"), never 0."""
    a, b = np.asarray(a, dtype=float), np.asarray(b, dtype=float)
    with np.errstate(divide="ignore", invalid="ignore"):
        out = np.where(b > 0, a / b, np.nan)
    return out if out.ndim else float(out)


def kpis(df: pd.DataFrame) -> dict:
    """Headline KPIs. Rate metrics use only rows where both numerator and divisor are known."""
    spend, rev = df.spend_inr.sum(), df.revenue_inr.sum()
    ok_ctr = df.clicks.notna() & df.impressions.notna()
    ok_cvr = df.clicks.notna() & df.conversions.notna()
    ok_cpc = df.clicks.notna()
    ok_cpa = df.conversions.notna()
    return {
        "spend": float(spend),
        "revenue": float(rev),
        "roi": safe_div(rev - spend, spend),                       # RULE-01
        "roas": safe_div(rev, spend),                              # RULE-02
        "ctr": safe_div(df.clicks[ok_ctr].sum(), df.impressions[ok_ctr].sum()),                    # RULE-03
        "cpc": safe_div(df.spend_inr[ok_cpc].sum(), df.clicks[ok_cpc].sum()),
        "conversion_rate": safe_div(df.conversions[ok_cvr].sum(), df.clicks[ok_cvr].sum()),
        "cpa": safe_div(df.spend_inr[ok_cpa].sum(), df.conversions[ok_cpa].sum()),
        "rows": int(len(df)),
    }


def by_group(df: pd.DataFrame, col) -> pd.DataFrame:
    """KPI table for each value of `col` (str or list of str). OQ-01, OQ-06, OQ-07, OQ-08."""
    rows = []
    for key, g in df.groupby(col, observed=True):
        k = kpis(g)
        k["group"] = key
        rows.append(k)
    out = pd.DataFrame(rows)
    if out.empty:
        return pd.DataFrame(columns=["group", "spend", "revenue", "roi", "roas", "ctr", "cpc",
                                     "conversion_rate", "cpa", "rows"])
    cols = ["group", "spend", "revenue", "roi", "roas", "ctr", "cpc", "conversion_rate", "cpa", "rows"]
    return out[cols].sort_values("roas", ascending=False).reset_index(drop=True)


def monthly(df: pd.DataFrame) -> pd.DataFrame:
    """Spend, revenue, ROI per calendar month. OQ-02."""
    g = df.groupby("year_month")[["spend_inr", "revenue_inr"]].sum().reset_index()
    g["roi"] = safe_div(g.revenue_inr - g.spend_inr, g.spend_inr)
    g["roas"] = safe_div(g.revenue_inr, g.spend_inr)
    return g


def seasonality_index(df: pd.DataFrame) -> pd.DataFrame:
    """ROAS by calendar month number divided by overall ROAS (1.00 = average). OQ-02."""
    g = df.groupby("month")[["spend_inr", "revenue_inr"]].sum()
    overall = safe_div(g.revenue_inr.sum(), g.spend_inr.sum())
    g["index"] = safe_div(g.revenue_inr, g.spend_inr) / overall
    return g.reset_index()[["month", "index"]]


def correlation(df: pd.DataFrame, by=None) -> pd.DataFrame:
    """Pearson and Spearman correlation of spend and revenue (daily rows). OQ-03."""
    def one(g, label):
        if len(g) < 3 or g.spend_inr.nunique() < 2 or g.revenue_inr.nunique() < 2:
            return dict(group=label, n=len(g), pearson_r=np.nan, pearson_p=np.nan,
                        spearman_rho=np.nan, spearman_p=np.nan)
        pr, pp = stats.pearsonr(g.spend_inr, g.revenue_inr)
        sr, sp = stats.spearmanr(g.spend_inr, g.revenue_inr)
        return dict(group=label, n=len(g), pearson_r=pr, pearson_p=pp, spearman_rho=sr, spearman_p=sp)
    rows = [one(df, "All channels")]
    if by:
        for key, g in df.groupby(by, observed=True):
            rows.append(one(g, key))
    return pd.DataFrame(rows)


def diminishing_returns(df: pd.DataFrame, by="channel_name") -> pd.DataFrame:
    """Log-log regression revenue ~ spend per group. slope < 1 means diminishing returns. OQ-04."""
    rows = []
    for key, g in df[(df.spend_inr > 0) & (df.revenue_inr > 0)].groupby(by, observed=True):
        if len(g) < 5 or g.spend_inr.nunique() < 3:
            continue
        r = stats.linregress(np.log(g.spend_inr), np.log(g.revenue_inr))
        # one-sided check: slope significantly below 1
        if r.stderr > 0:
            p_below_1 = float(stats.t.cdf((r.slope - 1) / r.stderr, df=len(g) - 2))
        else:                      # perfect fit: no uncertainty
            p_below_1 = 0.0 if r.slope < 1 else 1.0
        verdict = "Diminishing returns" if (p_below_1 < ALPHA and r.slope < 1) else "No clear diminishing returns"
        rows.append(dict(group=key, n=len(g), slope=r.slope, intercept=r.intercept,
                         r_squared=r.rvalue ** 2, p_slope_below_1=p_below_1, verdict=verdict))
    return pd.DataFrame(rows)


def negative_campaigns(df: pd.DataFrame) -> pd.DataFrame:
    """Campaigns with ROI < 0 over their whole run, ranked by money lost. OQ-05 / BR-03 / BR-04."""
    g = df.groupby(["campaign_id", "campaign_name", "channel_name", "campaign_type"])[
        ["spend_inr", "revenue_inr"]].sum().reset_index()
    g["roi"] = safe_div(g.revenue_inr - g.spend_inr, g.spend_inr)
    g["loss_inr"] = g.spend_inr - g.revenue_inr
    return g[g.roi < 0].sort_values("loss_inr", ascending=False).reset_index(drop=True)


def wasted_share(df: pd.DataFrame) -> dict:
    neg = negative_campaigns(df)
    total = df.spend_inr.sum()
    return {"campaigns": int(len(neg)),
            "spend_on_negative": float(neg.spend_inr.sum()),
            "share_of_spend": safe_div(neg.spend_inr.sum(), total)}


def channel_roi_test(df: pd.DataFrame) -> dict:
    """Is ROI different between channels? ROI per campaign-week, ANOVA + Kruskal-Wallis. OQ-09 / BR-07."""
    w = df.groupby(["campaign_id", "channel_name", "week_start"])[["spend_inr", "revenue_inr"]].sum().reset_index()
    w = w[w.spend_inr > 0]
    w["roi"] = (w.revenue_inr - w.spend_inr) / w.spend_inr
    groups = [g.roi.to_numpy() for _, g in w.groupby("channel_name") if len(g) >= 3]
    if len(groups) < 2:
        return dict(ok=False, message="Need at least 2 channels with 3+ campaign-weeks each.")
    f, pf = stats.f_oneway(*groups)
    h, pk = stats.kruskal(*groups)
    sig = bool(pf < ALPHA and pk < ALPHA)
    return dict(ok=True, groups=len(groups), n=int(len(w)), anova_f=float(f), anova_p=float(pf),
                kruskal_h=float(h), kruskal_p=float(pk), significant=sig,
                verdict=("ROI differs between channels (p < 0.05 in both tests)." if sig else
                         "No reliable ROI difference between channels (RULE-07)."))


def fit_response_curves(df: pd.DataFrame) -> pd.DataFrame:
    """Weekly power-law revenue = a * spend^b per channel (used by the what-if). OQ-10 / BR-08."""
    w = df.groupby(["channel_name", "week_start"])[["spend_inr", "revenue_inr"]].sum().reset_index()
    w = w[(w.spend_inr > 0) & (w.revenue_inr > 0)]
    rows = []
    for ch, g in w.groupby("channel_name"):
        if len(g) < 5 or g.spend_inr.nunique() < 3:
            continue
        r = stats.linregress(np.log(g.spend_inr), np.log(g.revenue_inr))
        rows.append(dict(channel_name=ch, a=float(np.exp(r.intercept)), b=float(r.slope),
                         mean_weekly_spend=float(g.spend_inr.mean()), weeks=int(len(g)),
                         r_squared=float(r.rvalue ** 2)))
    return pd.DataFrame(rows)


def what_if(df: pd.DataFrame, from_channel: str, to_channel: str, pct: float) -> dict:
    """Estimated weekly revenue change if `pct` % of a channel's spend moves to another (RULE-08: an estimate)."""
    if from_channel == to_channel:
        return dict(ok=False, message="Pick two different channels.")
    if not 0 < pct <= 100:
        return dict(ok=False, message="Share moved must be between 0 and 100%.")
    c = fit_response_curves(df).set_index("channel_name")
    if from_channel not in c.index or to_channel not in c.index:
        return dict(ok=False, message="Not enough data for one of the channels under the current filters.")
    f, t = c.loc[from_channel], c.loc[to_channel]
    move = f.mean_weekly_spend * pct / 100.0
    rev = lambda p, s: p.a * s ** p.b
    lose = rev(f, f.mean_weekly_spend) - rev(f, f.mean_weekly_spend - move)
    gain = rev(t, t.mean_weekly_spend + move) - rev(t, t.mean_weekly_spend)
    return dict(ok=True, moved_weekly_inr=float(move), revenue_lost=float(lose), revenue_gained=float(gain),
                net_weekly_change=float(gain - lose),
                note="Estimate from fitted weekly curves; assumes the past relationship continues. Not a forecast.")

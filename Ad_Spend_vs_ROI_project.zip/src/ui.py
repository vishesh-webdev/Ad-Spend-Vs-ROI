"""Shared UI: Tailwind header / KPI cards (rendered in an iframe), cached data, shared sidebar filters."""
import sys
from pathlib import Path

import pandas as pd
import streamlit as st
import streamlit.components.v1 as components

sys.path.insert(0, str(Path(__file__).resolve().parent))
from data_loader import load_clean  # noqa: E402

RED, INK, GREY, CARD, PINK = "#A51C30", "#151514", "#5E5E5B", "#F4F1F1", "#D9B5BC"
PALETTE = [RED, "#3A3A38", "#D9B5BC", "#8A8A86", "#C9546A", "#6B6B68", "#E8CFD4"]
TAILWIND = '<script src="https://cdn.tailwindcss.com"></script>'


def setup(title: str, icon: str = "📈"):
    st.set_page_config(page_title=f"{title} | Ad Spend vs ROI", page_icon=icon, layout="wide")


@st.cache_data(show_spinner="Loading data ...")
def get_data():
    raw, good, rejects = load_clean()
    return raw, good, rejects


def header(title: str, subtitle: str):
    components.html(f"""{TAILWIND}
    <div class="rounded-xl px-6 py-4" style="background:{INK};font-family:Calibri,Arial,sans-serif">
      <div class="text-xs tracking-wide" style="color:{PINK}">AD SPEND vs ROI ANALYSIS &nbsp;|&nbsp; ABES MCA Data Analytics</div>
      <div class="text-2xl font-bold text-white">{title}</div>
      <div class="text-sm" style="color:#F4F1F1">{subtitle}</div>
    </div>""", height=110)


def _fmt_inr(v):
    if pd.isna(v):
        return "n/a"
    if abs(v) >= 1e7:
        return f"₹{v / 1e7:.2f} Cr"
    if abs(v) >= 1e5:
        return f"₹{v / 1e5:.2f} L"
    return f"₹{v:,.0f}"


def kpi_cards(k: dict):
    """UI component: KPI card row. `k` comes from analysis.kpis()."""
    na = lambda v, f: "n/a" if pd.isna(v) else f.format(v)
    items = [("Total spend", _fmt_inr(k["spend"])), ("Revenue", _fmt_inr(k["revenue"])),
             ("ROI", na(k["roi"], "{:.0%}")), ("ROAS", na(k["roas"], "{:.2f}x")),
             ("CTR", na(k["ctr"], "{:.2%}")), ("CPA", _fmt_inr(k["cpa"]))]
    cards = "".join(f"""<div class="rounded-lg p-3" style="background:{CARD}">
        <div class="text-xs" style="color:{GREY}">{n}</div>
        <div class="text-xl font-bold" style="color:{RED}">{v}</div></div>""" for n, v in items)
    components.html(f"""{TAILWIND}
      <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3" style="font-family:Calibri,Arial,sans-serif">{cards}</div>""",
                    height=100)


def insight(text: str):
    st.markdown(f"""<div style="background:{CARD};border-left:5px solid {RED};padding:10px 14px;border-radius:6px">
    <b style="color:{RED}">Insight</b><br>{text}</div>""", unsafe_allow_html=True)


def sidebar_filters(df: pd.DataFrame) -> pd.DataFrame:
    """Shared filters kept in st.session_state so every page shows the same slice (BR-13)."""
    st.sidebar.header("Filters")
    dmin, dmax = df.perf_date.min().date(), df.perf_date.max().date()
    st.session_state.setdefault("f_dates", (dmin, dmax))
    for key, col in (("f_channel", "channel_name"), ("f_region", "region_name"), ("f_category", "category_name")):
        st.session_state.setdefault(key, sorted(df[col].unique()))
    dates = st.sidebar.date_input("Date range", key="f_dates", min_value=dmin, max_value=dmax)
    for key, col, label in (("f_channel", "channel_name", "Channel"), ("f_region", "region_name", "Region"),
                            ("f_category", "category_name", "Product category")):
        st.sidebar.multiselect(label, sorted(df[col].unique()), key=key)
    if st.sidebar.button("Reset filters"):
        for key in ("f_dates", "f_channel", "f_region", "f_category"):
            st.session_state.pop(key, None)
        st.rerun()
    lo, hi = (dates if isinstance(dates, (tuple, list)) and len(dates) == 2 else (dmin, dmax))
    m = (df.perf_date.dt.date >= lo) & (df.perf_date.dt.date <= hi)
    m &= df.channel_name.isin(st.session_state["f_channel"])
    m &= df.region_name.isin(st.session_state["f_region"])
    m &= df.category_name.isin(st.session_state["f_category"])
    out = df[m]
    st.sidebar.caption(f"{len(out):,} of {len(df):,} rows selected")
    return out


def page_start(title: str, subtitle: str, icon="📈"):
    """Common start of every page: config, header, data, filters. Returns (filtered_df, all_clean_df)."""
    setup(title, icon)
    header(title, subtitle)
    _, good, _ = get_data()
    f = sidebar_filters(good)
    if f.empty:
        st.warning("No data for these filters. Widen the date range or select more channels, regions or categories.")
        st.stop()
    return f, good

"""
generate_data.py - Synthetic data for "Ad Spend vs ROI Analysis"
Author : Vishesh Yadav (Roll 2500320140165), MCA 2nd yr (Data Analytics), ABES
Run    : python src/generate_data.py

Creates (random seed 42, 100% synthetic, fictional names/places):
  data/app.db                      SQLite, foreign keys ON, DDL below
  data/<table>.csv                 one CSV per table + vw_ad_analysis.csv
  data/ad_spend_roi_data.xlsx      one sheet per table + joined view
  data/injected_issues.csv         answer key for the planted data-quality issues
  data/validation_report.md        row counts, FK check, range check, pattern check

NOTE: the table design is provisional (derived from Step 1 fields) until Step 8
is formalised.
"""
import math
import sqlite3
from pathlib import Path

import numpy as np
import pandas as pd

SEED = 42
ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
START, END = pd.Timestamp("2024-11-01"), pd.Timestamp("2026-10-31")
N_CAMPAIGNS = 60
N_LOSS_MAKING = 3          # planted loss-making campaigns (PATTERN 4)

# --------------------------------------------------------------------------- DDL
DDL = """
PRAGMA foreign_keys = ON;

CREATE TABLE dim_channel (
    channel_id     INTEGER PRIMARY KEY,
    channel_name   TEXT    NOT NULL UNIQUE,
    channel_group  TEXT    NOT NULL CHECK (channel_group IN ('Search','Social','Video','Direct','Display')),
    billing_model  TEXT    NOT NULL CHECK (billing_model IN ('CPC','CPM','Flat')),
    funnel_stage   TEXT    NOT NULL CHECK (funnel_stage IN ('Upper','Mid','Lower'))
);

CREATE TABLE dim_region (
    region_id    INTEGER PRIMARY KEY,
    region_name  TEXT NOT NULL UNIQUE,
    hub_city     TEXT NOT NULL,
    market_tier  TEXT NOT NULL CHECK (market_tier IN ('Metro','Tier-1','Tier-2'))
);

CREATE TABLE dim_product_category (
    category_id          INTEGER PRIMARY KEY,
    category_name        TEXT NOT NULL UNIQUE,
    avg_order_value_inr  REAL NOT NULL CHECK (avg_order_value_inr > 0),
    gross_margin_pct     REAL NOT NULL CHECK (gross_margin_pct BETWEEN 0 AND 100)
);

CREATE TABLE dim_campaign (
    campaign_id       INTEGER PRIMARY KEY,
    campaign_name     TEXT    NOT NULL UNIQUE,
    channel_id        INTEGER NOT NULL REFERENCES dim_channel(channel_id),
    region_id         INTEGER NOT NULL REFERENCES dim_region(region_id),
    category_id       INTEGER NOT NULL REFERENCES dim_product_category(category_id),
    campaign_type     TEXT    NOT NULL CHECK (campaign_type IN ('Awareness','Performance')),
    objective         TEXT    NOT NULL,
    campaign_manager  TEXT,
    start_date        TEXT    NOT NULL,
    end_date          TEXT    NOT NULL,
    daily_budget_inr  REAL    NOT NULL CHECK (daily_budget_inr > 0),
    CHECK (end_date >= start_date)
);

-- No UNIQUE(campaign_id, perf_date) on purpose: duplicate days are a planted
-- data-quality issue that the cleaning step (RULE-10) must find and report.
CREATE TABLE fact_ad_performance (
    perf_id      INTEGER PRIMARY KEY,
    campaign_id  INTEGER NOT NULL REFERENCES dim_campaign(campaign_id),
    perf_date    TEXT    NOT NULL,
    spend_inr    REAL    NOT NULL CHECK (spend_inr >= 0),
    impressions  INTEGER CHECK (impressions >= 0),
    clicks       INTEGER CHECK (clicks >= 0),
    conversions  INTEGER CHECK (conversions >= 0),
    revenue_inr  REAL    NOT NULL CHECK (revenue_inr >= 0),
    CHECK (clicks <= impressions),
    CHECK (conversions <= clicks)
);
CREATE INDEX ix_fact_campaign ON fact_ad_performance(campaign_id);
CREATE INDEX ix_fact_date     ON fact_ad_performance(perf_date);

CREATE VIEW vw_ad_analysis AS
SELECT
    f.perf_id, f.campaign_id, c.campaign_name, c.campaign_type, c.objective, c.campaign_manager,
    c.daily_budget_inr,
    ch.channel_id, ch.channel_name, ch.channel_group, ch.funnel_stage,
    r.region_id, r.region_name,
    p.category_id, p.category_name, p.avg_order_value_inr, p.gross_margin_pct,
    f.perf_date,
    CAST(strftime('%Y', f.perf_date) AS INTEGER)                      AS year,
    CAST(strftime('%m', f.perf_date) AS INTEGER)                      AS month,
    strftime('%Y-%m', f.perf_date)                                    AS year_month,
    'Q' || ((CAST(strftime('%m', f.perf_date) AS INTEGER) + 2) / 3)   AS quarter,
    CASE strftime('%w', f.perf_date) WHEN '0' THEN 'Sunday' WHEN '1' THEN 'Monday'
         WHEN '2' THEN 'Tuesday' WHEN '3' THEN 'Wednesday' WHEN '4' THEN 'Thursday'
         WHEN '5' THEN 'Friday' ELSE 'Saturday' END                   AS day_name,
    CASE WHEN strftime('%w', f.perf_date) IN ('0','6') THEN 1 ELSE 0 END AS is_weekend,
    CASE WHEN strftime('%m-%d', f.perf_date) BETWEEN '10-15' AND '11-15' THEN 1 ELSE 0 END AS is_festival_season,
    f.spend_inr, f.impressions, f.clicks, f.conversions, f.revenue_inr,
    CASE WHEN f.spend_inr > 0 THEN ROUND((f.revenue_inr - f.spend_inr) * 1.0 / f.spend_inr, 4) END AS roi,
    CASE WHEN f.spend_inr > 0 THEN ROUND(f.revenue_inr * 1.0 / f.spend_inr, 4) END                 AS roas,
    CASE WHEN f.impressions > 0 THEN ROUND(f.clicks * 1.0 / f.impressions, 6) END                  AS ctr,
    CASE WHEN f.clicks > 0 THEN ROUND(f.spend_inr * 1.0 / f.clicks, 2) END                         AS cpc_inr,
    CASE WHEN f.clicks > 0 THEN ROUND(f.conversions * 1.0 / f.clicks, 6) END                       AS conversion_rate,
    CASE WHEN f.conversions > 0 THEN ROUND(f.spend_inr * 1.0 / f.conversions, 2) END               AS cpa_inr,
    ROUND(f.revenue_inr - f.spend_inr, 2)                                                          AS profit_inr
FROM fact_ad_performance f
JOIN dim_campaign         c  ON c.campaign_id = f.campaign_id
JOIN dim_channel          ch ON ch.channel_id = c.channel_id
JOIN dim_region           r  ON r.region_id   = c.region_id
JOIN dim_product_category p  ON p.category_id = c.category_id;
"""

# ------------------------------------------------------------------ master data
CHANNELS = [
    (1, "Google Search",   "Search",  "CPC",  "Lower"),
    (2, "Meta (Facebook)", "Social",  "CPM",  "Mid"),
    (3, "Instagram",       "Social",  "CPM",  "Mid"),
    (4, "YouTube",         "Video",   "CPM",  "Upper"),
    (5, "LinkedIn",        "Social",  "CPC",  "Mid"),
    (6, "E-mail",          "Direct",  "Flat", "Lower"),
    (7, "Display Network", "Display", "CPM",  "Upper"),
]
# cpc (INR), ctr, target ROAS, daily budget range, P(awareness)
CH_PARAM = {
    1: dict(cpc=14.0, ctr=0.045, roas=3.8, budget=(10000, 24000), p_aw=0.10),
    2: dict(cpc=9.0,  ctr=0.012, roas=2.4, budget=(8000, 18000),  p_aw=0.40),
    3: dict(cpc=10.0, ctr=0.010, roas=1.9, budget=(6000, 14000),  p_aw=0.50),
    4: dict(cpc=6.0,  ctr=0.006, roas=2.0, budget=(8000, 20000),  p_aw=0.80),
    5: dict(cpc=38.0, ctr=0.006, roas=2.2, budget=(4000, 10000),  p_aw=0.30),
    6: dict(cpc=3.5,  ctr=0.028, roas=5.5, budget=(1500, 4000),   p_aw=0.10),
    7: dict(cpc=4.0,  ctr=0.003, roas=1.5, budget=(4000, 10000),  p_aw=0.85),
}
REGIONS = [
    (1, "North",   "Himavatpur",  "Metro"),
    (2, "South",   "Kaveripuram", "Metro"),
    (3, "East",    "Sundarbagh",  "Tier-1"),
    (4, "West",    "Arabhat",     "Metro"),
    (5, "Central", "Madhyanagar", "Tier-2"),
]
REGION_CVR = {1: 1.00, 2: 1.05, 3: 0.92, 4: 1.10, 5: 0.88}
CATEGORIES = [
    (1, "Electronics Accessories", 1800.0, 28.0),
    (2, "Home & Kitchen",          2600.0, 34.0),
    (3, "Fashion & Apparel",       1500.0, 42.0),
    (4, "Health & Wellness",       1200.0, 46.0),
]
CAT_CVR = {1: 0.95, 2: 0.90, 3: 1.10, 4: 1.05}
AOV_MEAN = 1775.0

SEASON_CVR = {1: 1.05, 2: 0.95, 3: 1.00, 4: 0.95, 5: 0.95, 6: 0.85,
              7: 0.85, 8: 0.95, 9: 1.00, 10: 1.25, 11: 1.35, 12: 1.15}
SEASON_CPC = {10: 1.12, 11: 1.18, 12: 1.08}

MANAGERS = ["Aarav Mehra", "Diya Nair", "Kabir Sethi", "Ishita Rao",
            "Rohan Bhatt", "Meera Kulkarni", "Vihaan Joshi", "Tara Menon"]
THEME_BY_MONTH = {10: "Diwali Dhamaka", 11: "Diwali Dhamaka", 12: "Year End Mega Sale",
                  1: "Republic Day Sale", 2: "Valentine Specials", 3: "Holi Colours Offer",
                  4: "Summer Fresh", 5: "Summer Fresh", 6: "Monsoon Mania",
                  7: "Monsoon Mania", 8: "Independence Day Deals", 9: "Festive Early Bird"}
CH_SHORT = {1: "Search", 2: "Meta", 3: "Insta", 4: "YouTube", 5: "LinkedIn", 6: "Email", 7: "Display"}
CAT_SHORT = {1: "Electronics", 2: "HomeKitchen", 3: "Fashion", 4: "Wellness"}
OBJ = {"Performance": ["Drive purchases", "Cart recovery", "Repeat orders"],
       "Awareness": ["Brand reach", "Festive awareness", "New range launch"]}


def build_campaigns(rng):
    chan = [1, 2, 3, 4, 5, 6, 7] * 8 + [1, 2, 3, 4]
    rng.shuffle(chan)
    combos = [(r, c) for r in range(1, 6) for c in range(1, 5)] * 2
    combos += [(int(rng.integers(1, 6)), int(rng.integers(1, 5))) for _ in range(N_CAMPAIGNS - len(combos))]
    rng.shuffle(combos)
    rows = []
    for i in range(N_CAMPAIGNS):
        ch, (rg, ct) = chan[i], combos[i]
        ctype = "Awareness" if rng.random() < CH_PARAM[ch]["p_aw"] else "Performance"
        if i < 12:     # make sure the first months of the window are covered
            start = START + pd.Timedelta(days=int(rng.integers(0, 90)))
        else:
            start = START + pd.Timedelta(days=int(rng.integers(0, (pd.Timestamp("2026-05-31") - START).days)))
        end = min(start + pd.Timedelta(days=int(rng.integers(150, 331)) - 1), END)
        lo, hi = CH_PARAM[ch]["budget"]
        rows.append(dict(
            campaign_id=i + 1,
            campaign_name=f"{THEME_BY_MONTH[start.month]} - {CH_SHORT[ch]} - {CAT_SHORT[ct]} #{i + 1:02d}",
            channel_id=ch, region_id=rg, category_id=ct, campaign_type=ctype,
            objective=str(rng.choice(OBJ[ctype])),
            campaign_manager=str(rng.choice(MANAGERS)),
            start_date=start, end_date=end,
            daily_budget_inr=float(round(rng.uniform(lo, hi), -2)),
            eff=float(rng.lognormal(0, 0.18)),
        ))
    camp = pd.DataFrame(rows)
    # PATTERN 4: a few clearly loss-making campaigns
    cand = camp[camp.channel_id.isin([2, 3, 4, 7]) & (camp.campaign_type == "Awareness")].index.to_numpy()
    pick = rng.choice(cand, size=N_LOSS_MAKING, replace=False)
    camp.loc[pick, "eff"] = rng.uniform(0.28, 0.40, size=N_LOSS_MAKING)
    # DQ: 2 campaigns with a missing manager name
    miss = rng.choice(len(camp), size=2, replace=False)
    camp.loc[miss, "campaign_manager"] = None
    return camp


def build_facts(rng, camp):
    frames = [pd.DataFrame({"campaign_id": c.campaign_id,
                            "perf_date": pd.date_range(c.start_date, c.end_date)})
              for c in camp.itertuples()]
    f = pd.concat(frames, ignore_index=True)
    cm = camp.set_index("campaign_id")
    j = f.campaign_id
    ch = cm.channel_id.loc[j].to_numpy()
    cpc0 = np.array([CH_PARAM[x]["cpc"] for x in ch])
    ctr0 = np.array([CH_PARAM[x]["ctr"] for x in ch])
    cvr0 = np.array([CH_PARAM[x]["roas"] * CH_PARAM[x]["cpc"] / AOV_MEAN for x in ch])
    ref = np.array([sum(CH_PARAM[x]["budget"]) / 2 for x in ch])
    budget = cm.daily_budget_inr.loc[j].to_numpy()
    eff = cm.eff.loc[j].to_numpy()
    aw = (cm.campaign_type.loc[j] == "Awareness").to_numpy()
    start = cm.start_date.loc[j].to_numpy()
    reg = np.array([REGION_CVR[x] for x in cm.region_id.loc[j]])
    cat_id = cm.category_id.loc[j].to_numpy()
    cat = np.array([CAT_CVR[x] for x in cat_id])
    aov = np.array([CATEGORIES[x - 1][2] for x in cat_id])

    n = len(f)
    d = f.perf_date
    m = d.dt.month.to_numpy()
    dow = d.dt.dayofweek.to_numpy()
    day_idx = (d.to_numpy() - start).astype("timedelta64[D]").astype(int)
    md = d.dt.strftime("%m-%d").to_numpy()
    fest = np.where((md >= "10-15") & (md <= "11-15"), 1.10, 1.0)             # PATTERN 2

    spend = budget * np.where(day_idx < 7, 0.7, 1.0) * np.where(dow >= 5, 1.08, 1.0) \
        * rng.lognormal(0, 0.30, n)
    spend = np.round(spend, 2)
    cpc = cpc0 * np.vectorize(SEASON_CPC.get)(m, 1.0) * rng.lognormal(0, 0.10, n)
    clicks_mean = spend / cpc
    clicks = rng.poisson(clicks_mean)
    ctr = ctr0 * np.where(aw, 0.8, 1.15)
    impressions = np.maximum(rng.poisson(clicks_mean / ctr * rng.lognormal(0, 0.05, n)), clicks)
    season = np.vectorize(SEASON_CVR.get)(m)
    dimin = np.clip((spend / ref) ** -0.3, 0.4, 2.0)                           # PATTERN 3
    cvr = cvr0 * np.where(aw, 0.8, 1.1) * eff * season * fest * reg * cat * dimin
    conv = rng.binomial(clicks, np.clip(cvr, 0, 1))
    revenue = np.round(conv * aov * rng.lognormal(0, 0.12, n), 2)

    out = pd.DataFrame({"campaign_id": j.to_numpy(), "perf_date": d, "spend_inr": spend,
                        "impressions": impressions, "clicks": clicks,
                        "conversions": conv, "revenue_inr": revenue})
    out = out.sort_values(["perf_date", "campaign_id"], kind="stable").reset_index(drop=True)
    out.insert(0, "perf_id", np.arange(1, len(out) + 1))
    out["perf_date"] = out.perf_date.dt.strftime("%Y-%m-%d")
    for c in ("impressions", "clicks", "conversions"):
        out[c] = out[c].astype("Int64")
    return out


def inject_issues(rng, fact):
    """Plant data-quality problems; return (fact, answer-key DataFrame)."""
    log = []
    n = len(fact)
    for col, share in (("impressions", 0.020), ("clicks", 0.025), ("conversions", 0.020)):
        idx = rng.choice(n, size=int(n * share), replace=False)
        fact.loc[idx, col] = pd.NA
        log += [dict(perf_id=int(fact.at[i, "perf_id"]), issue="missing_value", column=col, original="", new="") for i in idx]
    idx = rng.choice(n, size=5, replace=False)
    for i in idx:                                       # spend entered 12x too high
        old = fact.at[i, "spend_inr"]
        fact.at[i, "spend_inr"] = round(old * 12, 2)
        log.append(dict(perf_id=int(fact.at[i, "perf_id"]), issue="outlier_spend", column="spend_inr", original=old, new=fact.at[i, "spend_inr"]))
    ok = fact.index[(fact.revenue_inr > 1.5 * fact.spend_inr) & (fact.spend_inr < 20000)].to_numpy()
    idx = rng.choice(ok, size=3, replace=False)
    for i in idx:                                       # revenue entered 25x too high
        old = fact.at[i, "revenue_inr"]
        fact.at[i, "revenue_inr"] = round(old * 25, 2)
        log.append(dict(perf_id=int(fact.at[i, "perf_id"]), issue="outlier_revenue", column="revenue_inr", original=old, new=fact.at[i, "revenue_inr"]))
    idx = rng.choice(n, size=3, replace=False)
    dup = fact.loc[idx].copy()                          # same day loaded twice
    dup["perf_id"] = np.arange(n + 1, n + 4)
    log += [dict(perf_id=int(r.perf_id), issue="duplicate_row", column="campaign_id+perf_date",
                 original=f"copy of perf_id {int(fact.at[i, 'perf_id'])}", new="") for r, i in zip(dup.itertuples(), idx)]
    fact = pd.concat([fact, dup], ignore_index=True)
    return fact, pd.DataFrame(log)


def clean_val(v):
    if v is None or v is pd.NA:
        return None
    if isinstance(v, float) and math.isnan(v):
        return None
    if isinstance(v, np.generic):
        return v.item()
    return v


def insert(con, table, df):
    cols = list(df.columns)
    q = f"INSERT INTO {table} ({','.join(cols)}) VALUES ({','.join('?' * len(cols))})"
    con.executemany(q, [tuple(clean_val(v) for v in r) for r in df.itertuples(index=False, name=None)])


# --------------------------------------------------------------- validation
def md_table(df):
    head = "| " + " | ".join(map(str, df.columns)) + " |\n|" + "---|" * len(df.columns) + "\n"
    return head + "\n".join("| " + " | ".join(str(x) for x in r) + " |" for r in df.itertuples(index=False))


def validate(con, issues):
    L = ["# Validation report - Ad Spend vs ROI Analysis (synthetic data, seed 42)\n"]
    cnt = {t: con.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0] for t in
           ("dim_channel", "dim_region", "dim_product_category", "dim_campaign", "fact_ad_performance")}
    view_cols = [r[1] for r in con.execute("PRAGMA table_info(vw_ad_analysis)")]
    plan = {"dim_channel": "7", "dim_region": "5", "dim_product_category": "4",
            "dim_campaign": "60", "fact_ad_performance": "10,000+ (Step 1 objective O-01)"}
    L.append("## 1. Row counts\n")
    L.append(md_table(pd.DataFrame([[t, c, plan[t]] for t, c in cnt.items()], columns=["table", "rows", "plan"])))
    L.append(f"\nJoined view `vw_ad_analysis`: {cnt['fact_ad_performance']} rows x {len(view_cols)} columns.\n")
    results = {"counts": cnt, "view_columns": len(view_cols)}

    L.append("## 2. Foreign-key check\n")
    fk = con.execute("PRAGMA foreign_key_check").fetchall()
    L.append(f"`PRAGMA foreign_key_check` violations: **{len(fk)}**\n")
    results["fk_violations"] = len(fk)

    L.append("## 3. Range / rule check (on the raw, unclean data)\n")
    q = lambda s: con.execute(s).fetchone()[0]
    rng_rows = [
        ["spend_inr < 0", q("SELECT COUNT(*) FROM fact_ad_performance WHERE spend_inr<0"), "0"],
        ["revenue_inr < 0", q("SELECT COUNT(*) FROM fact_ad_performance WHERE revenue_inr<0"), "0"],
        ["clicks > impressions", q("SELECT COUNT(*) FROM fact_ad_performance WHERE clicks>impressions"), "0"],
        ["conversions > clicks", q("SELECT COUNT(*) FROM fact_ad_performance WHERE conversions>clicks"), "0"],
        ["perf_date outside 2024-11-01..2026-10-31", q("SELECT COUNT(*) FROM fact_ad_performance WHERE perf_date<'2024-11-01' OR perf_date>'2026-10-31'"), "0"],
        ["perf_date outside campaign start/end", q("SELECT COUNT(*) FROM fact_ad_performance f JOIN dim_campaign c USING(campaign_id) WHERE f.perf_date<c.start_date OR f.perf_date>c.end_date"), "0"],
        ["campaign without a manager (missing)", q("SELECT COUNT(*) FROM dim_campaign WHERE campaign_manager IS NULL"), "2 planted"],
    ]
    L.append(md_table(pd.DataFrame(rng_rows, columns=["check", "violations", "expected"])))

    L.append("\n## 4. Planted data-quality issues (answer key: data/injected_issues.csv)\n")
    n = cnt["fact_ad_performance"]
    miss = {c: q(f"SELECT COUNT(*) FROM fact_ad_performance WHERE {c} IS NULL") for c in ("impressions", "clicks", "conversions")}
    dups = q("SELECT COUNT(*) FROM (SELECT campaign_id, perf_date FROM fact_ad_performance GROUP BY 1,2 HAVING COUNT(*)>1)")
    spend_out = q("SELECT COUNT(*) FROM fact_ad_performance f JOIN dim_campaign c USING(campaign_id) WHERE f.spend_inr > 6*c.daily_budget_inr")
    rev_out = q("SELECT COUNT(*) FROM fact_ad_performance WHERE spend_inr>0 AND revenue_inr/spend_inr > 30")
    rows = [[f"missing {c}", v, f"{v / n:.2%}", "2-3%"] for c, v in miss.items()]
    rows += [["duplicate (campaign, date) pairs", dups, "", "3"],
             ["spend outliers (> 6x daily budget)", spend_out, "", "5"],
             ["revenue outliers (ROAS > 30)", rev_out, "", "3"]]
    L.append(md_table(pd.DataFrame(rows, columns=["issue", "found", "share", "planted"])))
    results.update(miss=miss, dups=dups, spend_out=spend_out, rev_out=rev_out)

    # patterns checked on clean rows (planted problem rows removed)
    bad = set(issues.perf_id)
    df = pd.read_sql("SELECT * FROM vw_ad_analysis", con)
    c = df[~df.perf_id.isin(bad)].copy()
    L.append("\n## 5. Patterns built into the data (measured on rows without planted issues)\n")
    g = c.groupby("channel_name")[["spend_inr", "revenue_inr"]].sum()
    g["ROAS"] = (g.revenue_inr / g.spend_inr).round(2)
    g["ROI"] = ((g.revenue_inr - g.spend_inr) / g.spend_inr).round(2)
    g = g.sort_values("ROAS", ascending=False).reset_index()
    g["spend_inr"] = g.spend_inr.round(0).astype(int)
    g["revenue_inr"] = g.revenue_inr.round(0).astype(int)
    L.append("**P1 - Channel ROI ranking** (E-mail and Google Search best, Display and Instagram weakest)\n")
    L.append(md_table(g))
    mm = c.groupby("month")[["spend_inr", "revenue_inr"]].sum()
    mm["ROAS"] = (mm.revenue_inr / mm.spend_inr)
    mm["index_vs_avg"] = (mm.ROAS / (c.revenue_inr.sum() / c.spend_inr.sum())).round(2)
    L.append("\n**P2 - Seasonality** (ROAS index by calendar month; 1.00 = average; Oct-Dec above, Jun-Jul below)\n")
    L.append(md_table(mm.reset_index()[["month", "index_vs_avg"]]))
    sl = []
    for name, grp in c[(c.spend_inr > 0) & (c.revenue_inr > 0)].groupby("channel_name"):
        s, _ = np.polyfit(np.log(grp.spend_inr), np.log(grp.revenue_inr), 1)
        sl.append([name, round(float(s), 2)])
    L.append("\n**P3 - Diminishing returns** (log-log slope of revenue on spend; below 1.0 means each extra rupee earns less)\n")
    L.append(md_table(pd.DataFrame(sl, columns=["channel", "slope"])))
    cp = c.groupby(["campaign_id", "campaign_name"])[["spend_inr", "revenue_inr"]].sum().reset_index()
    cp["ROI"] = (cp.revenue_inr - cp.spend_inr) / cp.spend_inr
    neg = cp[cp.ROI < 0]
    L.append(f"\n**P4 - Loss-making campaigns:** {len(neg)} of {len(cp)} campaigns ({len(neg) / len(cp):.0%}) have ROI < 0; "
             f"they absorbed {neg.spend_inr.sum() / cp.spend_inr.sum():.1%} of total spend.\n")
    t = c.groupby("campaign_type")[["spend_inr", "revenue_inr"]].sum()
    t["ROAS"] = (t.revenue_inr / t.spend_inr).round(2)
    L.append("**P5 - Awareness vs Performance** (performance campaigns return more)\n")
    L.append(md_table(t.reset_index()[["campaign_type", "ROAS"]]))
    r = c.groupby("region_name")[["spend_inr", "revenue_inr"]].sum()
    r["ROAS"] = (r.revenue_inr / r.spend_inr).round(2)
    L.append("\n**P6 - Regions** (West and South best, Central and East weakest)\n")
    L.append(md_table(r.sort_values("ROAS", ascending=False).reset_index()[["region_name", "ROAS"]]))
    tot = df.spend_inr.sum()
    L.append(f"\nTotal spend in dataset: INR {tot / 1e7:.2f} crore over 24 months; total revenue INR {df.revenue_inr.sum() / 1e7:.2f} crore.\n")
    results.update(channel_roas=g.to_dict("records"), neg_campaigns=int(len(neg)), n_campaigns=int(len(cp)),
                   total_spend=float(tot))
    return "\n".join(L), results


def style_workbook(path):
    from openpyxl import load_workbook
    from openpyxl.styles import Font, PatternFill, Alignment
    wb = load_workbook(path)
    for ws in wb:
        for cell in ws[1]:
            cell.font = Font(name="Arial", bold=True, color="FFFFFF", size=10)
            cell.fill = PatternFill("solid", fgColor="1F3A5F")
            cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        ws.freeze_panes = "A2"
        ws.auto_filter.ref = ws.dimensions
        for col in ws.columns:
            w = max(len(str(c.value)) if c.value is not None else 0 for c in list(col)[:200])
            ws.column_dimensions[col[0].column_letter].width = min(max(w + 2, 10), 42)
    wb.save(path)


def main():
    DATA.mkdir(exist_ok=True)
    rng = np.random.default_rng(SEED)
    camp = build_campaigns(rng)
    fact = build_facts(rng, camp)
    fact, issues = inject_issues(rng, fact)

    dim_channel = pd.DataFrame(CHANNELS, columns=["channel_id", "channel_name", "channel_group", "billing_model", "funnel_stage"])
    dim_region = pd.DataFrame(REGIONS, columns=["region_id", "region_name", "hub_city", "market_tier"])
    dim_cat = pd.DataFrame(CATEGORIES, columns=["category_id", "category_name", "avg_order_value_inr", "gross_margin_pct"])
    dim_campaign = camp.drop(columns="eff").copy()
    dim_campaign["start_date"] = dim_campaign.start_date.dt.strftime("%Y-%m-%d")
    dim_campaign["end_date"] = dim_campaign.end_date.dt.strftime("%Y-%m-%d")
    tables = {"dim_channel": dim_channel, "dim_region": dim_region, "dim_product_category": dim_cat,
              "dim_campaign": dim_campaign, "fact_ad_performance": fact}

    db = DATA / "app.db"
    db.unlink(missing_ok=True)
    con = sqlite3.connect(db)
    con.execute("PRAGMA foreign_keys = ON")
    con.executescript(DDL)
    con.execute("PRAGMA foreign_keys = ON")
    for t, df in tables.items():
        insert(con, t, df)
    con.commit()
    (DATA / "schema.sql").write_text(DDL, encoding="utf-8")

    view = pd.read_sql("SELECT * FROM vw_ad_analysis", con)
    for t, df in tables.items():
        df.to_csv(DATA / f"{t}.csv", index=False)
    view.to_csv(DATA / "vw_ad_analysis.csv", index=False)
    issues.to_csv(DATA / "injected_issues.csv", index=False)

    xlsx = DATA / "ad_spend_roi_data.xlsx"
    with pd.ExcelWriter(xlsx, engine="openpyxl") as w:
        for t, df in tables.items():
            df.to_excel(w, sheet_name=t, index=False)
        view.to_excel(w, sheet_name="vw_ad_analysis", index=False)
    style_workbook(xlsx)

    report, res = validate(con, issues)
    (DATA / "validation_report.md").write_text(report, encoding="utf-8")
    con.close()
    print(report)
    return res


if __name__ == "__main__":
    main()

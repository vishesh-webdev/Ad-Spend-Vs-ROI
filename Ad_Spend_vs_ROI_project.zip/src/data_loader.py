"""Load data/app.db and clean it (BR-12, RULE-05, RULE-06, RULE-10)."""
import sqlite3
from pathlib import Path

import numpy as np
import pandas as pd

DB_PATH = Path(__file__).resolve().parents[1] / "data" / "app.db"
KEY_COLS = ["campaign_id", "perf_date", "spend_inr", "revenue_inr"]
SPEND_SPIKE_X = 6      # spend above 6x the campaign's daily budget = outlier
ROAS_LIMIT = 30        # row ROAS above 30 = outlier


def load_raw(db_path=DB_PATH) -> pd.DataFrame:
    """Read the joined analysis view exactly as stored (raw, with its planted problems)."""
    db_path = Path(db_path)
    if not db_path.exists():
        raise FileNotFoundError(f"Database not found: {db_path}")
    con = sqlite3.connect(db_path)
    try:
        df = pd.read_sql("SELECT * FROM vw_ad_analysis", con)
    finally:
        con.close()
    return df


def clean(df: pd.DataFrame):
    """Return (clean_df, rejects_df). Nothing is silently fixed: every rejected row gets a reason."""
    df = df.copy()
    reason = pd.Series("", index=df.index, dtype=object)

    def mark(mask, text):
        nonlocal reason
        mask = mask & (reason == "")
        reason = reason.mask(mask, text)

    mark(df[KEY_COLS].isna().any(axis=1), "missing key field")
    mark((df.spend_inr < 0) | (df.revenue_inr < 0), "negative amount")
    dup = df.duplicated(subset=["campaign_id", "perf_date"], keep="first")
    mark(dup, "duplicate campaign-day")
    mark(df.spend_inr > SPEND_SPIKE_X * df.daily_budget_inr, "spend outlier (> 6x daily budget)")
    mark((df.spend_inr > 0) & (df.revenue_inr / df.spend_inr.where(df.spend_inr > 0) > ROAS_LIMIT),
         "revenue outlier (ROAS > 30)")

    rejects = df[reason != ""].assign(reject_reason=reason[reason != ""])
    good = df[reason == ""].copy()
    # RULE-06: a ratio with an unusable divisor is "not available" (NaN), never 0
    good["perf_date"] = pd.to_datetime(good["perf_date"])
    good["week_start"] = good["perf_date"] - pd.to_timedelta(good["perf_date"].dt.dayofweek, unit="D")
    return good.reset_index(drop=True), rejects.reset_index(drop=True)


def missing_summary(df: pd.DataFrame) -> pd.DataFrame:
    cols = ["impressions", "clicks", "conversions", "campaign_manager"]
    out = pd.DataFrame({"column": cols,
                        "missing_rows": [int(df[c].isna().sum()) for c in cols]})
    out["share_%"] = (out.missing_rows / len(df) * 100).round(2)
    return out


def load_clean(db_path=DB_PATH):
    raw = load_raw(db_path)
    good, rejects = clean(raw)
    return raw, good, rejects
